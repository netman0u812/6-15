#!/usr/bin/env bash
# object-viewer-web-service.sh — CCD Platform local HTTP server
# Usage: ./object-viewer-web-service.sh [port]
# Serves ~/Documents/IP_Lookup/ on 127.0.0.1 only.
# Stop: Ctrl-C (clean exit)

PORT=${1:-8080}
ROOT="$(cd "$(dirname "$0")" && pwd)"

echo "CCD Platform — Local Server"
echo "  Root : $ROOT"
echo "  URL  : http://127.0.0.1:$PORT/edl_catalog.html"
echo "  Stop : Ctrl-C"
echo ""

cd "$ROOT"
python3 -m http.server "$PORT" --bind 127.0.0.1 2>&1 | grep -v "^127\."
